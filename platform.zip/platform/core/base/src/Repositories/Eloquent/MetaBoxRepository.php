<?php

namespace Botble\Base\Repositories\Eloquent;

use Botble\Base\Repositories\Interfaces\MetaBoxInterface;
use Botble\Support\Repositories\Eloquent\RepositoriesAbstract;

class MetaBoxRepository extends RepositoriesAbstract implements MetaBoxInterface
{
}
