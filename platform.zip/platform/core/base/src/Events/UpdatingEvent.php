<?php

namespace Botble\Base\Events;

class UpdatingEvent extends Event
{
}
