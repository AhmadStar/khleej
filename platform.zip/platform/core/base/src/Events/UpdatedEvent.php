<?php

namespace Botble\Base\Events;

class UpdatedEvent extends Event
{
}
