import RepeaterComponent from './form/fields/RepeaterComponent';

vueApp.booting(vue => {
    vue.component('repeater-component', RepeaterComponent);
});
