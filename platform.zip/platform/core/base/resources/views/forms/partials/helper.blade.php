<div class="help-ts">
    <i class="fa fa-info-circle"></i>
    <span>{!! $content !!}</span>
</div>