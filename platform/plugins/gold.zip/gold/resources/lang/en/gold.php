<?php

return [
    'name'   => 'Gold',
    'create' => 'New gold',
    'edit'   => 'Edit gold',
];
