<?php

namespace Botble\Gold\Repositories\Eloquent;

use Botble\Support\Repositories\Eloquent\RepositoriesAbstract;
use Botble\Gold\Repositories\Interfaces\GoldInterface;

class GoldRepository extends RepositoriesAbstract implements GoldInterface
{
}
