<?php

namespace Botble\Gold\Repositories\Interfaces;

use Botble\Support\Repositories\Interfaces\RepositoryInterface;

interface GoldInterface extends RepositoryInterface
{
}
