<?php

namespace Botble\Gold\Repositories\Caches;

use Botble\Support\Repositories\Caches\CacheAbstractDecorator;
use Botble\Gold\Repositories\Interfaces\GoldInterface;

class GoldCacheDecorator extends CacheAbstractDecorator implements GoldInterface
{

}
