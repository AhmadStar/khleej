<?php

if (!defined('GOLD_MODULE_SCREEN_NAME')) {
    define('GOLD_MODULE_SCREEN_NAME', 'gold');
}
