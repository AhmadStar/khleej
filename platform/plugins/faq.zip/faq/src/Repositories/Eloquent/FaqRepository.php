<?php

namespace Botble\Faq\Repositories\Eloquent;

use Botble\Support\Repositories\Eloquent\RepositoriesAbstract;
use Botble\Faq\Repositories\Interfaces\FaqInterface;

class FaqRepository extends RepositoriesAbstract implements FaqInterface
{
}
