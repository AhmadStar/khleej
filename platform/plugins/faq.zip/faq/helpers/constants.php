<?php

if (!defined('FAQ_CATEGORY_MODULE_SCREEN_NAME')) {
    define('FAQ_CATEGORY_MODULE_SCREEN_NAME', 'faq_category');
}

if (!defined('FAQ_MODULE_SCREEN_NAME')) {
    define('FAQ_MODULE_SCREEN_NAME', 'faq');
}
